MyPath = r'C:\Users\mthompso\Desktop\DeleteThis\ExplicitUzDefExport'

def PostFinished(Analysis):   #this is run every time you solve or evaluate all results.
    ExportResults(Analysis)

def GetObjectsForExport():
    MyObjects=[]
    DefObjs = ExtAPI.DataModel.GetObjectsByType(DataModelObjectCategory.DirectionalDeformation)
    for DefObj in DefObjs:
        if DefObj.Location.GetType()==Ansys.Mechanical.Selection.PathLocation:
            if str(DefObj.NormalOrientation)=="ZAxis":
                MyObjects.append(DefObj)
    return MyObjects

def ExportResults(Analysis):
    MyObjs = GetObjectsForExport()
    for Obj in MyObjs:
        #FilePath = Analysis.WorkingDir+"Obj"+str(Obj.ObjectId)+".txt"
        FilePath = MyPath+"\\"+"Obj"+str(Obj.ObjectId)+".txt"

        RW = ResultWriter()
        RW.Object = Obj
        RW.Path = FilePath
        ExtAPI.Application.InvokeUIThread(WriteResults, RW)  #initiate this on the main UI thread.
    pass

#Create this object class to hold multiple information items you can pass to another function
class ResultWriter:
    def __init__(self):
        self.Object=None; self.Path = None

def WriteResults(RW): #on the main UI thread
    RW.Object.ExportToTextFile(True,RW.Path)